# Design System Inspired by Duolingo

## Product Overview

This package records a pasted learning-product design specification for a language-learning product. The product supports onboarding, lesson paths, answer selection, streak progress, and immediate answer feedback. It provides a consistent way to build high-attention learning screens with large rounded controls, clear progress, immediate correction, 2px borders, and 4px tactile lower edges. It helps a learner understand the next task before they need to parse surrounding interface chrome.

## Source Context

- Source: `context/input-DESIGN.md`
- URL: `designmd://design-system-inspired-by-duolingo`
- Available evidence: written design guidance only.
- Missing evidence: website capture, source code, logo files, mascot or illustration files, and font files.

## Package Contents

- `DESIGN.md` records source-backed rules for color, typography, layout, components, motion, and anti-patterns.
- `BRAND.md` records provenance, token roles, and asset gaps.
- `brand.json` holds registered metadata and persistent engine-level seed values.
- `colors_and_type.css` has reusable tokens and base card and button primitives.
- `system/` has generated CSS, JSON, light and dark kits, an artifact gallery, and generated samples.
- `preview/` has focused cards for colors, type, spacing, geometry, buttons, and motion.
- `ui_kits/app/` has a source-backed lesson-screen example.

## Preview manifest

- `preview/colors-primary.html`
- `preview/typography-specimens.html`
- `preview/spacing-tokens.html`
- `preview/radius-and-shadows.html`
- `preview/components-buttons.html`
- `preview/motion-states.html`

## Reuse Workflow

1. Read `DESIGN.md` and the focused preview card for the pattern you need.
2. Load `colors_and_type.css` for hand-authored HTML, or use `system/variables.css` and `system/theme.json` for generated token consumers.
3. Start a lesson step from `ui_kits/app/index.html`. Keep one clear prompt, a visible progress state, and one primary action.
4. Check `BRAND.md` before adding imagery, logos, or fonts. The source names some assets but does not provide them.
5. When changing engine-level tokens, edit `brand.json.seed`, run the finalizer, then inspect `system/kit.html` and `system/kit.dark.html`.

## Preserved artifacts

There are no preserved brand assets, build artifacts, source examples, or font files because the input contained only written guidance. No `assets/brand-files`, `build/runtime`, `fonts/family`, or `source_examples/components` files were copied. The existing `assets/` folder contains unrelated project material and is not a source for this extracted system. This package preserves the written source evidence and generated token artifacts instead.
