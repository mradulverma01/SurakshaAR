# Applied lesson kit

## Structure

`index.html` is a source-backed lesson-screen example. It loads `../../colors_and_type.css` and composes a progress track, a direct instruction, answer choices, and one primary check action. There are no separate component files because the source provided a component specification, not captured product code. The conceptual components are `App`, `LessonProgress`, `AnswerChoice`, and `LessonAction`.

## Usage

Start with the progress track, then put one direct prompt inside a lesson card. Keep answer choices neutral until selection. Use one primary action at the bottom of the card. Preserve the 2px border and 4px lower edge where a control must feel pressable.

## Design notes

The example uses a 48px minimum main action, a visible lesson fraction, and one dominant task. It follows the colors, typography, spacing, radius, and button-state rules in `DESIGN.md`. It intentionally omits mascot artwork because no source asset was supplied.

## Source basis

The layout comes from the source instructions for a centered lesson tree, 16px cards, 16px progress bars, 12px inputs, and direct lesson feedback. It is an implementation example for future projects, not a copy of an existing Duolingo screen.

## Components

The source does not include a `components/` directory. If this kit becomes modular, split `App` into `LessonProgress`, `AnswerChoice`, and `LessonAction` files under `components/`, then keep the current composition and token use intact. The generic package roles `Composer` and `PreviewCard` are not source modules and should not be added unless a future lesson flow needs them.
