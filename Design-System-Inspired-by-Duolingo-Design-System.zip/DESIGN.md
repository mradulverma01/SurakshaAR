---
name: "Design System Inspired by Duolingo"
category: Brands
surface: web
colors:
  snow: "#ffffff"
  eel: "#f7f7f7"
  eel-black: "#3c3c3c"
  wolf: "#777777"
  swan: "#e5e5e5"
  owl-green: "#58cc02"
  streak-orange: "#ff9600"
---

# Design System Inspired by Duolingo

> Category: Brands

> Surface: web

*A bright, tactile learning-product system built around progress and clear feedback.*

Source-backed guidance for a Duolingo-inspired learning interface. It pairs owl green actions with thick borders, 4px bottom shadows, rounded geometry, and direct progress feedback.

## Color Palette

| Role | Name | Hex | Usage |
| --- | --- | --- | --- |
| background | Snow | `#ffffff` | Primary page canvas and raised button face. |
| surface | Eel | `#f7f7f7` | Section breaks and secondary surface fills. |
| foreground | Eel Black | `#3c3c3c` | Headings, body copy, and strong iconography. |
| muted | Wolf | `#777777` | Secondary text, captions, and low-emphasis controls. |
| border | Swan | `#e5e5e5` | Standard 2px borders, inset blocks, and the light bottom edge on neutral controls. |
| accent | Owl Green | `#58cc02` | Primary actions, correct answers, and active lesson states. |
| accent-secondary | Streak Orange | `#ff9600` | Streak progress and premium-energy moments. |

## Typography
- **Display:** Feather Bold — weights 700, 800 — fallbacks: DIN Round Pro, Helvetica Neue, sans-serif
- **Body:** Mona Sans — weights 400, 500, 600 — fallbacks: Helvetica Neue, system-ui, sans-serif
- **Mono:** JetBrains Mono — weights 400, 600 — fallbacks: ui-monospace, Menlo, monospace

## Voice & Tone

- **Adjectives:** encouraging, direct, playful, specific
- **Tone:** Warm, concise, and progress-oriented. Celebrate a correct step, then state the next one.

### Messaging pillars
- Make the next learning action obvious.
- Turn progress into a visible, motivating state.
- Give immediate feedback with a clear reason.

### Vocabulary
- **Use:** Continue, Check, Correct, Streak, Lesson, XP
- **Avoid:** Long abstract instructions, Flat, neutral confirmation copy, Celebration language on routine controls

## Imagery

- **Style:** Rounded, high-contrast character illustration with simple color blocks and filled, rounded icons.
- **Subjects:** Duo as an active guide in onboarding, errors, and streak moments, Lesson and progress states, Skill-specific filled icons
- **Treatment:** Use the mascot as a response to a product state. Keep visual focus on the current task and feedback.
- **Avoid:** Mascot artwork used as a static decoration, Thin outline icon sets, Sharp-edged editorial photography

## Layout

- **Radius:** 12px controls, 16px cards, 9999px chips and progress bars
- **Border weight:** 2px standard borders with a 4px bottom edge on tactile controls
- **Spacing:** 4px base scale: 4, 8, 12, 16, 24, 32, 48, 64

### Posture rules
- Use a 1080px maximum content container with 24px gutters.
- Keep the lesson path to a centered 320px column on desktop.
- Use large, rounded, touchable controls with a 4px bottom shadow.
- Pair high-saturation action colors with a darker pressed edge.
- Reserve oversized display type for lesson, streak, and progress moments.
