# Design System Inspired by Duolingo brand notes

## Provenance

The system comes from `context/input-DESIGN.md`. No live site, logo file, illustration file, or font file was provided. Every named color and component value in this package comes from that pasted source.

## Primary tokens

- Background: Snow `#ffffff`
- Surface: Eel `#f7f7f7`
- Foreground: Eel Black `#3c3c3c`
- Muted: Wolf `#777777`
- Border: Swan `#e5e5e5`
- Accent: Owl Green `#58cc02`
- Accent secondary: Streak Orange `#ff9600`

## Implementation note

`brand.json.seed` is the authored engine override. It sets the generated component family to green primary, 48px control height, 16px base radius, 2px borders, and a 4px spacing unit. Running the brand finalizer regenerates `system/` from this seed.

## Gaps

Feather Bold, Mona Sans, and JetBrains Mono are named in the source but were not supplied as font files. The system records their fallback stacks. No visual asset may be represented as the real Duo mark or character without a supplied or licensed source file.
