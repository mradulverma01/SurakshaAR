---
name: duolingo-inspired-learning-ui
description: Build learning-product interfaces from the source-backed tactile control and progress rules in this package.
user-invocable: true
---

# Duolingo-inspired learning UI

## What is inside

`DESIGN.md` defines color roles, typography, layout, components, motion, and anti-patterns. `colors_and_type.css` provides reusable CSS tokens. `system/` contains regenerated tokens and component kits. `preview/` isolates the visual rules for review. `ui_kits/app/` shows the rules in a lesson screen.

## Source context

The package comes from `context/input-DESIGN.md`. It has no source code, real imagery, logos, or font files. Do not claim a supplied asset is official when the source only names it.

## When to use this skill

Use it for learning flows, quiz feedback, lesson progress, streak states, or product surfaces that need rounded tactile controls and immediate feedback.

## How to use

Read `README.md` and `DESIGN.md` first. Load `colors_and_type.css` for hand-authored HTML. Use the generated `system/variables.css` or `system/theme.json` for the registered token layer. Reuse component rules from `ui_kits/app/` and inspect `preview/` before creating a new variation.

## Design system highlights

The primary action is owl green with a 4px darker bottom edge. Use 2px borders, 16px cards, 12px inputs, large rounded labels, and 4px spacing increments. Tie secondary colors to their product state rather than using them as decoration.
